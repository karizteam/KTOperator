/**
 * Web terminal preview for the ktOperator interactive console.
 * Spawns `node dist/cli.js` inside a real PTY (node-pty) per browser
 * connection and bridges it to xterm.js over WebSocket.
 * DEMO ONLY — not part of the published package.
 */
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node-pty';
import { WebSocketServer } from 'ws';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const CLI = path.join(root, 'dist', 'cli.js');
const PORT = Number(process.env.PORT ?? 7681);
const DEMO_HOME = process.env.OPERATOR_HOME ?? '/tmp/op-web-home';

const HTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>ktOperator — interactive console</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/css/xterm.min.css">
<style>
  html, body { margin:0; height:100%; background:#0b0e14; color:#c7d0e0; font-family:ui-monospace,Menlo,Consolas,monospace; }
  #bar { padding:8px 14px; background:#12161f; border-bottom:1px solid #1f2635; display:flex; gap:12px; align-items:center; font-size:13px; }
  #bar b { color:#7aa2f7; }
  #dot { width:9px; height:9px; border-radius:50%; background:#e0af68; display:inline-block; }
  #dot.on { background:#9ece6a; }
  #term { padding:10px 12px; height:calc(100% - 40px); box-sizing:border-box; }
  a { color:#7aa2f7; }
</style>
</head>
<body>
<div id="bar"><span id="dot"></span><b>ktOperator console</b><span>interactive demo · each browser tab = one fresh console process</span></div>
<div id="term"></div>
<script src="https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/lib/xterm.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@xterm/addon-fit@0.10.0/lib/addon-fit.min.js"></script>
<script>
  const term = new Terminal({ cursorBlink:true, fontSize:14, theme:{ background:'#0b0e14', foreground:'#c7d0e0', cursor:'#7aa2f7', selectionBackground:'#283457', cyan:'#7dcfff', magenta:'#bb9af7', green:'#9ece6a', yellow:'#e0af68', red:'#f7768e', blue:'#7aa2f7' } });
  const fit = new FitAddon.FitAddon();
  term.loadAddon(fit);
  term.open(document.getElementById('term'));
  const fitAll = () => { fit.fit(); };
  window.addEventListener('resize', () => { fitAll(); sendSize(); });
  fitAll();

  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const ws = new WebSocket(proto + '://' + location.host + '/pty');
  const dot = document.getElementById('dot');
  const sendSize = () => { if (ws.readyState === 1) ws.send(JSON.stringify({type:'resize', cols:term.cols, rows:term.rows})); };

  ws.onopen = () => { dot.classList.add('on'); sendSize(); term.focus(); };
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.type === 'output') term.write(m.data);
    if (m.type === 'exit') { dot.classList.remove('on'); term.write('\\r\\n\\x1b[2m[console process exited — refresh to start over]\\x1b[0m\\r\\n'); }
  };
  ws.onclose = () => { dot.classList.remove('on'); term.write('\\r\\n\\x1b[2m[connection closed — refresh to reconnect]\\x1b[0m\\r\\n'); };
  term.onData((d) => { if (ws.readyState === 1) ws.send(JSON.stringify({type:'input', data:d})); });
</script>
</body>
</html>`;

const server = http.createServer((req, res) => {
  if (req.url === '/' || req.url === '/index.html') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    res.end(HTML);
    return;
  }
  res.writeHead(404).end();
});

const wss = new WebSocketServer({ server, path: '/pty' });

wss.on('connection', (ws) => {
  const pty = spawn('node', [CLI], {
    name: 'xterm-256color',
    cols: 100,
    rows: 30,
    cwd: root,
    env: { ...process.env, OPERATOR_HOME: DEMO_HOME, TERM: 'xterm-256color', COLORTERM: 'truecolor' },
  });

  pty.onData((data) => {
    if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'output', data }));
  });
  pty.onExit(({ exitCode }) => {
    if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type: 'exit', code: exitCode }));
  });

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(String(raw)); } catch { return; }
    if (msg.type === 'input' && typeof msg.data === 'string') pty.write(msg.data);
    else if (msg.type === 'resize' && msg.cols > 0 && msg.rows > 0) {
      try { pty.resize(Math.min(msg.cols, 300), Math.min(msg.rows, 100)); } catch { /* racing an exited pty */ }
    }
  });
  ws.on('close', () => { try { pty.kill(); } catch { /* already gone */ } });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`ktOperator web terminal on http://0.0.0.0:${PORT} (OPERATOR_HOME=${DEMO_HOME})`);
});
