import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import { ManagedProcessRunner, isShellExecutable, resolveExecutable } from '../../src/core/execution/managed-process.js';
import { SandboxError } from '../../src/errors/errors.js';

const isWindows = process.platform === 'win32';
const PATH = process.env['PATH'] ?? '';

function echoSpec(args: string[], extra?: Partial<Parameters<ManagedProcessRunner['run']>[0]>) {
  return {
    argv: [process.execPath, '-e', `console.log(${JSON.stringify(args.join(' '))})`],
    cwd: os.tmpdir(),
    env: { PATH },
    timeoutMs: 10_000,
    maxOutputBytes: 64 * 1024,
    ...extra,
  };
}

describe('managed process runner', () => {
  it('runs structured argv without any shell', async () => {
    const runner = new ManagedProcessRunner();
    const r = await runner.run(echoSpec(['hello world; $(whoami) `id`']));
    assert.equal(r.exitCode, 0);
    assert.match(r.stdout, /hello world; \$\(whoami\) `id`/, 'shell metacharacters must remain inert data');
  });

  it('enforces timeouts and kills the process', async () => {
    const runner = new ManagedProcessRunner();
    const r = await runner.run({
      argv: [process.execPath, '-e', 'setTimeout(() => {}, 60000)'],
      cwd: os.tmpdir(),
      env: { PATH },
      timeoutMs: 300,
      maxOutputBytes: 1024,
    });
    assert.equal(r.timedOut, true);
    assert.equal(r.exitCode, null);
  });

  it('caps output and reports truncation', async () => {
    const runner = new ManagedProcessRunner();
    const r = await runner.run({
      argv: [process.execPath, '-e', 'process.stdout.write("x".repeat(1_000_000))'],
      cwd: os.tmpdir(),
      env: { PATH },
      timeoutMs: 15_000,
      maxOutputBytes: 4096,
    });
    assert.equal(r.outputTruncated, true);
    assert.ok(r.stdout.length <= 4096);
  });

  it('kills the process tree on abort (child processes included)', async () => {
    const runner = new ManagedProcessRunner();
    const controller = new AbortController();
    // Spawn a node parent that spawns its own long-lived child.
    const script = isWindows
      ? `require('child_process').spawn(process.execPath,['-e','setTimeout(()=>{},9e5)']);setTimeout(()=>{},9e5)`
      : `require('child_process').spawn(process.execPath,['-e','setTimeout(()=>{},9e5)'],{detached:false});setTimeout(()=>{},9e5)`;
    const promise = runner.run({
      argv: [process.execPath, '-e', script],
      cwd: os.tmpdir(),
      env: { PATH },
      timeoutMs: 30_000,
      maxOutputBytes: 1024,
      signal: controller.signal,
    });
    setTimeout(() => controller.abort(), 300);
    const started = Date.now();
    const r = await promise;
    assert.equal(r.aborted, true);
    assert.ok(Date.now() - started < 10_000, 'abort must kill promptly, not wait for the 30s timeout');
  });

  it('records history for inspect_command_result and supports terminate', async () => {
    const runner = new ManagedProcessRunner();
    const done = runner.run(echoSpec(['recorded']));
    const r = await done;
    const inspected = runner.inspect(r.id);
    assert.ok(inspected && 'exitCode' in inspected && inspected.exitCode === 0);

    const running = runner.run({
      argv: [process.execPath, '-e', 'setTimeout(() => {}, 30000)'],
      cwd: os.tmpdir(),
      env: { PATH },
      timeoutMs: 60_000,
      maxOutputBytes: 1024,
    });
    await new Promise((res) => setTimeout(res, 200));
    const live = runner.list();
    assert.equal(live.length, 1);
    assert.equal(await runner.terminate(live[0]!.id), true);
    await running;
    assert.equal(runner.list().length, 0);
    assert.equal(await runner.terminate('no-such-id'), false);
  });

  it('never runs when the executable does not exist', async () => {
    const runner = new ManagedProcessRunner();
    const r = await runner.run(echoSpec(['x'], { argv: ['definitely-not-a-real-binary-xyz'] }));
    assert.notEqual(r.exitCode, 0);
    assert.match(r.stderr, /spawn error/);
  });
});

describe('executable resolution & shell detection', () => {
  it('resolves real executables from PATH', async () => {
    const node = await resolveExecutable(isWindows ? 'node' : 'node', PATH);
    assert.ok(node.length > 0);
  });

  it('refuses unknown executables', async () => {
    await assert.rejects(() => resolveExecutable('not-real-xyz-123', PATH), SandboxError);
  });

  it('flags shell interpreter names', () => {
    for (const sh of ['sh', 'bash', '/bin/bash', 'cmd.exe', 'powershell', 'pwsh']) {
      assert.equal(isShellExecutable(sh), true, sh);
    }
    assert.equal(isShellExecutable('node'), false);
    assert.equal(isShellExecutable('git'), false);
  });
});
