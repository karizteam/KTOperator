import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { parseSlashCommand } from '../../src/commands/console.js';

describe('parseSlashCommand', () => {
  it('returns null for regular messages', () => {
    assert.equal(parseSlashCommand('run the tests'), null);
    assert.equal(parseSlashCommand(''), null);
    assert.equal(parseSlashCommand('explain /etc/hosts'), null);
  });

  it('parses a bare command', () => {
    assert.deepEqual(parseSlashCommand('/exit'), { name: 'exit', args: '' });
    assert.deepEqual(parseSlashCommand('/sandbox'), { name: 'sandbox', args: '' });
  });

  it('parses command plus arguments', () => {
    assert.deepEqual(parseSlashCommand('/provider use or'), { name: 'provider', args: 'use or' });
    assert.deepEqual(parseSlashCommand('/model reload'), { name: 'model', args: 'reload' });
    assert.deepEqual(parseSlashCommand('/workspace /tmp/foo bar'), { name: 'workspace', args: '/tmp/foo bar' });
  });

  it('normalizes case and surrounding whitespace', () => {
    assert.deepEqual(parseSlashCommand('  /EXIT  '), { name: 'exit', args: '' });
    assert.deepEqual(parseSlashCommand('/Model Use GPT'), { name: 'model', args: 'Use GPT' });
  });

  it('does not treat a lone slash as a command', () => {
    assert.equal(parseSlashCommand('/'), null);
    assert.equal(parseSlashCommand('/ '), null);
  });
});
