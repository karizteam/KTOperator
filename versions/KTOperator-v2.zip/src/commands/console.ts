import { stdout } from 'node:process';
import path from 'node:path';
import { ConfigError, OperatorError, UserCancelledError, errorMessage } from '../errors/errors.js';
import { DEFAULT_KEY_ENV } from '../config/credentials.js';
import type { ProviderProfile, ProviderType } from '../config/schema.js';
import type { AIProvider, ChatMessage } from '../providers/interfaces/types.js';
import { createProvider } from '../providers/registry.js';
import { createToolRegistry } from '../tools/index.js';
import type { ToolContext } from '../tools/types.js';
import { buildSystemPrompt } from '../core/agent/system-prompt.js';
import { runAgentLoop } from '../core/agent/loop.js';
import { VERSION } from '../version.js';
import { workspaceSelect, workspaceShow } from './workspace.js';
import { sandboxStatus } from './sandbox.js';
import type { Runtime } from './runtime.js';

/**
 * The interactive ktOperator console — the default landing environment.
 * One continuous flow: pick a provider → enter the API key → models load →
 * pick a model → authorize the workspace → chatbox. There is no separate
 * `setup` command; everything happens right here.
 */

const PROVIDER_CHOICES: readonly { type: ProviderType; label: string; needsKey: boolean }[] = [
  { type: 'openrouter', label: 'OpenRouter — openrouter.ai (many models, one key)', needsKey: true },
  { type: 'openai', label: 'OpenAI', needsKey: true },
  { type: 'anthropic', label: 'Anthropic Claude', needsKey: true },
  { type: 'google', label: 'Google Gemini', needsKey: true },
  { type: 'openai-compatible', label: 'OpenAI-compatible endpoint (custom URL)', needsKey: true },
  { type: 'ollama', label: 'Ollama — local inference, no key', needsKey: false },
];

const HISTORY_CAP = 60;

interface ConsoleStack {
  profile: ProviderProfile;
  provider: AIProvider;
  model: string;
  system: string;
}

export interface SlashCommand {
  name: string;
  args: string;
}

/** Parse "/name args…" → { name, args }, or null when not a slash command. */
export function parseSlashCommand(input: string): SlashCommand | null {
  const trimmed = input.trim();
  if (!trimmed.startsWith('/')) return null;
  const space = trimmed.indexOf(' ');
  const name = (space === -1 ? trimmed.slice(1) : trimmed.slice(1, space)).toLowerCase();
  if (name === '') return null; // a lone '/' is not a command
  const args = space === -1 ? '' : trimmed.slice(space + 1).trim();
  return { name, args };
}

export async function consoleMain(rt: Runtime): Promise<number> {
  if (!rt.ui.interactive) {
    throw new ConfigError('The console needs an interactive terminal (TTY).', {
      hint: 'Use subcommands like `ktoperator run "<task>"` for non-interactive/JSON usage.',
    });
  }

  banner(rt);

  // ── Phase 1: provider + model (selection → key → models → pick) ──────────
  let stack = await ensureProviderAndModel(rt);
  rt.ui.success(`Provider ready: ${stack.profile.type} (${stack.profile.id}), model: ${stack.model}`);

  // ── Phase 2: workspace authorization ──────────────────────────────────────
  await ensureWorkspace(rt);

  // ── Phase 3: sandbox (report only; read-only tools work regardless) ───────
  const sandbox = rt.makeSandbox();
  await sandbox.prepare();
  if (sandbox.selectedId()) rt.ui.info(`Sandbox: ${sandbox.selectedId()}`);
  else rt.ui.warn('Sandbox: none available — command execution will be refused; analysis still works. See `ktoperator sandbox status`.');

  // ── Phase 4: chatbox ───────────────────────────────────────────────────────
  const registry = createToolRegistry();
  const approval = rt.makeApproval({});
  const sessionId = await rt.sessions.create({
    task: '(interactive console session)',
    provider: stack.profile.type,
    model: stack.model,
    ...(rt.config.workspace.current ? { workspace: rt.config.workspace.current.path } : {}),
  });
  const audit = rt.makeAudit(sessionId);
  await audit.record({ event: 'session.start', detail: { console: true, provider: stack.profile.type, model: stack.model } });

  const history: ChatMessage[] = [];
  let taskController: AbortController | null = null;
  let idleCtrlC = false;

  const onSigint = () => {
    if (taskController) {
      taskController.abort();
    } else if (idleCtrlC) {
      stdout.write('\n');
      process.exit(130);
    } else {
      idleCtrlC = true;
      stdout.write('\n(Ctrl+C again to exit, or type /exit)\n');
    }
  };
  process.on('SIGINT', onSigint);

  rt.ui.info('');
  rt.ui.info(`${rt.ui.bold('Chatbox ready.')} Type your task and press Enter. Slash commands: /help, /provider, /model, /workspace, /sandbox, /clear, /exit`);

  try {
    for (;;) {
      idleCtrlC = false;
      const input = (await ask(rt)).trim();
      if (input === '') continue;

      const slash = parseSlashCommand(input);
      if (slash) {
        const result = await handleSlash(rt, slash, stack, {
          replaceStack: (next) => {
            stack = next;
          },
          clearHistory: () => {
            history.length = 0;
          },
        });
        if (result === 'exit') break;
        continue;
      }

      try {
        await runConsoleTask(rt, {
          stack,
          sandbox,
          approval,
          registry,
          sessionId,
          audit,
          history,
          input,
          setController: (c) => (taskController = c),
        });
      } catch (err) {
        if (err instanceof UserCancelledError) {
          rt.ui.warn('Cancelled.');
        } else if (err instanceof OperatorError) {
          rt.ui.error(err.message);
          if (err.hint) rt.ui.info(rt.ui.dim(`hint: ${err.hint}`));
        } else {
          rt.ui.error(`Unexpected error: ${errorMessage(err)}`);
        }
      } finally {
        taskController = null;
      }
    }
  } finally {
    process.removeListener('SIGINT', onSigint);
  }

  rt.ui.info('Goodbye.');
  return 0;
}

/* ------------------------------------------------------------------ */
/* Provider + model onboarding                                         */
/* ------------------------------------------------------------------ */

export async function ensureProviderAndModel(rt: Runtime): Promise<ConsoleStack> {
  let profile: ProviderProfile | null = null;

  if (rt.config.providers.length > 0) {
    const options = rt.config.providers.map((p) => `${p.id} (${p.type}${p.model ? `, ${p.model}` : ''})${rt.config.defaultProvider === p.id ? ' — current default' : ''}`);
    const idx = await rt.ui.promptSelect('Select a provider profile, or add a new one:', [...options, '＋ Add a new provider…']);
    if (idx < rt.config.providers.length) {
      profile = rt.config.providers[idx]!;
    }
  }

  profile ??= await addProviderFlow(rt);

  // Ensure a credential exists before model loading.
  const key = await rt.credentials.resolve(profile);
  const needsKey = profile.type !== 'ollama';
  if (needsKey && !key.value) {
    rt.ui.warn(`No API key found for "${profile.id}".`);
    const entered = await rt.ui.promptInput(`API key for ${profile.type}`, { mask: true, required: true });
    await rt.credentials.set(profile.id, entered);
    rt.ui.success('Key stored securely (chmod 600).');
  }

  const model = await ensureModel(rt, profile, { keepCurrent: true });
  return finishStack(rt, profile, model);
}

async function addProviderFlow(rt: Runtime): Promise<ProviderProfile> {
  const idx = await rt.ui.promptSelect('Choose an AI provider:', PROVIDER_CHOICES.map((c) => c.label));
  const choice = PROVIDER_CHOICES[idx]!;

  const id = await rt.ui.promptInput('Profile name', { defaultValue: choice.type, required: true });
  if (rt.config.providers.some((p) => p.id === id)) {
    throw new ConfigError(`A profile named "${id}" already exists — choose another name.`);
  }

  let baseUrl: string | undefined;
  if (choice.type === 'openai-compatible') {
    baseUrl = await rt.ui.promptInput('Base URL (e.g. https://llm.example.com/v1)', { required: true });
  } else if (choice.type === 'ollama') {
    baseUrl = await rt.ui.promptInput('Ollama base URL', { defaultValue: 'http://127.0.0.1:11434/v1' });
  }

  const trustedLocal = choice.type === 'ollama' || (baseUrl !== undefined && /^https?:\/\/(127\.|localhost|\[::1\])/.test(baseUrl));

  let apiKeyEnv: string | undefined;
  let key: string | null = null;
  if (choice.needsKey) {
    const envName = DEFAULT_KEY_ENV[choice.type];
    const fromEnv = envName ? process.env[envName] : undefined;
    if (fromEnv) {
      rt.ui.success(`Using ${envName} from the environment.`);
      key = fromEnv;
    } else {
      key = await rt.ui.promptInput(`API key for ${choice.type}`, { mask: true, required: true });
      if (choice.type === 'openai-compatible') {
        apiKeyEnv = await rt.ui.promptInput('Preferred env var name (optional)', { defaultValue: 'OPENAI_COMPATIBLE_API_KEY' });
        if (apiKeyEnv.trim() === '') apiKeyEnv = undefined;
      }
    }
  }

  let referer: string | undefined;
  let title: string | undefined;
  if (choice.type === 'openrouter') {
    const r = await rt.ui.promptInput('HTTP-Referer attribution (optional)');
    const t = await rt.ui.promptInput('X-Title attribution (optional)');
    if (r.trim() !== '') referer = r;
    if (t.trim() !== '') title = t;
  }

  const profile: ProviderProfile = {
    id,
    type: choice.type,
    trustedLocal,
    ...(baseUrl ? { baseUrl } : {}),
    ...(apiKeyEnv ? { apiKeyEnv } : {}),
    ...(referer ? { referer } : {}),
    ...(title ? { title } : {}),
  };

  // Test + persist. Key goes to the protected store when it wasn't from env.
  rt.ui.step('Testing connection…');
  const provider = createProvider(profile, key, rt.config, { maxRetries: 0, timeoutMs: 25_000 });
  const test = await provider.testConnection?.();
  if (test?.ok) rt.ui.success(test.detail);
  else if (test) rt.ui.warn(`Connection test failed: ${test.detail} (profile saved; fix later with /provider)`);

  const envHadKey = choice.needsKey && DEFAULT_KEY_ENV[choice.type] && process.env[DEFAULT_KEY_ENV[choice.type]] === key;
  if (key && !envHadKey) await rt.credentials.set(id, key);

  rt.config = await rt.store.update((config) => {
    config.providers.push(profile);
    if (config.providers.length === 1) config.defaultProvider = profile.id;
  });

  return rt.config.providers.find((p) => p.id === id)!;
}

/** Load models and let the user pick; returns the chosen model id. */
async function ensureModel(rt: Runtime, profile: ProviderProfile, options: { keepCurrent?: boolean } = {}): Promise<string> {
  if (options.keepCurrent && profile.model) return profile.model;

  const provider = await rt.buildProvider(profile);
  let models: { id: string; label?: string; capabilities?: { toolCalling?: boolean } }[] = [];
  if (provider.listModels && provider.capabilities().modelListing) {
    rt.ui.step('Loading models…');
    try {
      models = await provider.listModels();
    } catch (err) {
      rt.ui.warn(`Could not load models: ${errorMessage(err)}`);
    }
  }

  let model: string;
  if (models.length > 0) {
    const top = models.slice(0, 20);
    const labels = top.map((m) => `${m.id}${m.capabilities?.toolCalling === false ? ' (no tool calling)' : ''}`);
    const idx = await rt.ui.promptSelect(
      `Select a model (${models.length} available):`,
      [...labels, models.length > 20 ? `… ${models.length - 20} more not shown — enter a model id manually` : 'Enter a model id manually…'],
    );
    model = idx < top.length ? top[idx]!.id : await rt.ui.promptInput('Model id', { required: true });
    if (top[idx]?.capabilities?.toolCalling === false) {
      rt.ui.warn('This model does not declare tool-calling support; the agent may not be able to act.');
    }
  } else {
    model = await rt.ui.promptInput('Model id', { ...(profile.model ? { defaultValue: profile.model } : {}), required: true });
  }

  rt.config = await rt.store.update((config) => {
    config.providers = config.providers.map((p) => (p.id === profile.id ? { ...p, model } : p));
    if (config.defaultProvider === profile.id || config.providers.length === 1) {
      config.defaultProvider = profile.id;
      config.defaultModel = model;
    }
  });

  return model;
}

function finishStack(rt: Runtime, profile: ProviderProfile, model: string): Promise<ConsoleStack> {
  return buildConsoleStack(rt, profile, model);
}

async function buildConsoleStack(rt: Runtime, profile: ProviderProfile, model: string): Promise<ConsoleStack> {
  const provider = await rt.buildProvider(profile);
  const boundary = await rt.workspaceBoundary();
  const sandbox = rt.makeSandbox();
  const system = buildSystemPrompt({
    workspaceRoot: boundary?.root ?? null,
    workspaceName: rt.config.workspace.current?.name ?? null,
    config: rt.config,
    platform: process.platform,
    sandboxLabel: sandbox.selectedId() ?? 'none',
    toolNames: createToolRegistry().names(),
  });
  return { profile, provider, model, system };
}

/* ------------------------------------------------------------------ */
/* Workspace onboarding                                                */
/* ------------------------------------------------------------------ */

async function ensureWorkspace(rt: Runtime): Promise<void> {
  const boundary = await rt.workspaceBoundary();
  if (boundary) {
    rt.ui.info(`Workspace: ${boundary.root}`);
    const keep = await rt.ui.confirm('Use this workspace?', false);
    if (keep) return;
  }
  const answer = await rt.ui.promptInput('Workspace to authorize', { defaultValue: process.cwd(), required: true });
  await workspaceSelect(rt, path.resolve(answer));
  await workspaceShow(rt);
}

/* ------------------------------------------------------------------ */
/* Slash commands                                                      */
/* ------------------------------------------------------------------ */

interface SlashEnv {
  replaceStack: (stack: ConsoleStack) => void;
  clearHistory: () => void;
}

async function handleSlash(rt: Runtime, slash: SlashCommand, stack: ConsoleStack, env: SlashEnv): Promise<'exit' | void> {
  switch (slash.name) {
    case 'exit':
    case 'quit':
      return 'exit';

    case 'help':
      rt.ui.info(
        [
          'Slash commands:',
          '  /provider            list profiles; /provider use <id> | /provider add',
          '  /model               show current; /model use <id> | /model reload',
          '  /workspace [path]    show or re-authorize the workspace',
          '  /sandbox             show sandbox status',
          '  /clear               clear the conversation view and context',
          '  /exit                leave the console',
          'Anything else is sent to the agent as a task. Approvals appear inline.',
        ].join('\n'),
      );
      return;

    case 'clear':
      env.clearHistory();
      stdout.write('\x1b[2J\x1b[0;0H');
      rt.ui.success('Context cleared.');
      return;

    case 'provider': {
      if (slash.args === '' || slash.args === 'list') {
        const rows = rt.config.providers.map((p) => `${p.id === stack.profile.id ? '→' : ' '} ${p.id} (${p.type})${p.model ? ` model=${p.model}` : ''}`);
        rt.ui.info(rows.join('\n') || 'No profiles. /provider add to create one.');
        rt.ui.info('Usage: /provider use <id>  ·  /provider add');
        return;
      }
      if (slash.args === 'add') {
        const profile = await addProviderFlow(rt);
        const model = await ensureModel(rt, profile);
        env.replaceStack(await buildConsoleStack(rt, profile, model));
        rt.ui.success(`Now using ${profile.id} / ${model}`);
        return;
      }
      if (slash.args.startsWith('use ')) {
        const id = slash.args.slice(4).trim();
        const profile = rt.config.providers.find((p) => p.id === id);
        if (!profile) {
          rt.ui.error(`No profile named "${id}".`);
          return;
        }
        const model = await ensureModel(rt, profile, { keepCurrent: Boolean(profile.model) });
        env.replaceStack(await buildConsoleStack(rt, profile, model));
        rt.ui.success(`Now using ${profile.id} / ${model}`);
        return;
      }
      rt.ui.error('Usage: /provider use <id>  ·  /provider add');
      return;
    }

    case 'model': {
      if (slash.args === '') {
        rt.ui.info(`Current model: ${stack.model} (provider ${stack.profile.id})`);
        rt.ui.info('Usage: /model use <id>  ·  /model reload');
        return;
      }
      if (slash.args === 'reload') {
        const model = await ensureModel(rt, stack.profile);
        env.replaceStack(await buildConsoleStack(rt, stack.profile, model));
        rt.ui.success(`Model: ${model}`);
        return;
      }
      if (slash.args.startsWith('use ')) {
        const model = slash.args.slice(4).trim();
        if (model === '') {
          rt.ui.error('Missing model id.');
          return;
        }
        rt.config = await rt.store.update((config) => {
          config.providers = config.providers.map((p) => (p.id === stack.profile.id ? { ...p, model } : p));
          if (config.defaultProvider === stack.profile.id) config.defaultModel = model;
        });
      
        env.replaceStack(await buildConsoleStack(rt, stack.profile, model));
        rt.ui.success(`Model: ${model}`);
        return;
      }
      rt.ui.error('Usage: /model use <id>  ·  /model reload');
      return;
    }

    case 'workspace': {
      if (slash.args === '') {
        await workspaceShow(rt);
        return;
      }
      await workspaceSelect(rt, path.resolve(slash.args));
      env.replaceStack(await buildConsoleStack(rt, stack.profile, stack.model));
      return;
    }

    case 'sandbox':
      await sandboxStatus(rt);
      return;

    default:
      rt.ui.error(`Unknown command: /${slash.name} — try /help`);
      return;
  }
}

/* ------------------------------------------------------------------ */
/* Running a chat task                                                 */
/* ------------------------------------------------------------------ */

interface TaskDeps {
  stack: ConsoleStack;
  sandbox: ReturnType<Runtime['makeSandbox']>;
  approval: ReturnType<Runtime['makeApproval']>;
  registry: ReturnType<typeof createToolRegistry>;
  sessionId: string;
  audit: ReturnType<Runtime['makeAudit']>;
  history: ChatMessage[];
  input: string;
  setController: (c: AbortController) => void;
}

async function runConsoleTask(rt: Runtime, deps: TaskDeps): Promise<void> {
  const { stack, sandbox, approval, registry, sessionId, audit, history, input } = deps;
  const controller = new AbortController();
  deps.setController(controller);

  const toolContext: ToolContext = {
    config: rt.config,
    workspace: await rt.workspaceBoundary(),
    approval,
    audit,
    backups: rt.backups,
    sandbox,
    sessionId,
    dryRun: false,
    signal: controller.signal,
    agentLabel: `${stack.profile.type} (${stack.profile.id}) / ${stack.model}`,
  };

  const pending: Promise<void>[] = [rt.sessions.appendMessage(sessionId, { role: 'user', content: input })];
  const fresh: ChatMessage[] = [];
  let streamed = false;

  const limits = rt.config.limits;
  const report = await runAgentLoop({
    provider: stack.provider,
    model: stack.model,
    system: stack.system,
    userTask: input,
    history: history.slice(),
    registry,
    toolContext,
    maxIterations: limits.maxIterations,
    maxToolCalls: limits.maxToolCalls,
    maxDurationMs: limits.maxDurationMs,
    ...(limits.maxTokens !== undefined ? { maxTokens: limits.maxTokens } : {}),
    stream: stack.provider.capabilities().streaming,
    signal: controller.signal,
    onText: (d) => {
      streamed = true;
      rt.ui.token(d);
    },
    onTextDone: () => {
      if (streamed) {
        rt.ui.endStream();
        streamed = false;
      }
    },
    onToolEvent: (ev) => {
      if (ev.type === 'start') rt.ui.step(rt.ui.dim(`→ ${ev.name}`));
      else rt.ui.step(rt.ui.dim(`${ev.ok ? '✔' : '✖'} ${ev.name}: ${(ev.summary ?? '').slice(0, 110)}`));
    },
    onMessage: (m) => {
      fresh.push(m);
      pending.push(rt.sessions.appendMessage(sessionId, m));
    },
  });

  history.push({ role: 'user', content: input }, ...fresh);
  if (history.length > HISTORY_CAP) history.splice(0, history.length - HISTORY_CAP);

  await Promise.allSettled(pending);
  await rt.sessions.appendReport(sessionId, report);
  await audit.record({ event: 'session.end', detail: { status: report.status, toolCalls: report.toolCallsTotal, denied: report.deniedCount, limitReason: report.limitReason ?? null } });

  if (!streamed && report.finalText) rt.ui.info(report.finalText);
  if (report.status !== 'completed') {
    rt.ui.warn(`Session ${report.status}${report.limitReason ? `: ${report.limitReason}` : ''}`);
  }
  if (report.toolCallsTotal > 0) {
    rt.ui.info(rt.ui.dim(`(${report.toolCallsTotal} tool call(s), ${report.deniedCount} denied, ${(report.durationMs / 1000).toFixed(1)}s)`));
  }
}

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */

function banner(rt: Runtime): void {
  rt.ui.info(rt.ui.bold(`KarizTeam ktOperator ${VERSION}`));
  rt.ui.info(rt.ui.dim('The AI proposes; the security engine disposes.'));
  rt.ui.info('');
}

/** One chat input; shares the UI's persistent line reader so bulk input is never swallowed. */
async function ask(rt: Runtime): Promise<string> {
  return rt.ui.question(rt.ui.magenta('you › '));
}
