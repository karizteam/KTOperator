import type { JSONSchema } from './json-schema.js';
import type { RiskTier } from '../security/policy.js';
import type { WorkspaceBoundary } from '../security/path-validation.js';
import type { ApprovalEngine } from '../security/approval.js';
import type { AuditLog } from '../security/audit.js';
import type { BackupManager } from '../recovery/backups.js';
import type { SandboxManager } from '../sandbox/manager.js';
import type { OperatorConfig } from '../config/schema.js';

export interface ToolContext {
  config: OperatorConfig;
  workspace: WorkspaceBoundary | null;
  approval: ApprovalEngine;
  audit: AuditLog;
  backups: BackupManager;
  sandbox: SandboxManager;
  sessionId: string;
  dryRun: boolean;
  signal?: AbortSignal | undefined;
  /** Live provider metadata for the running model (provider+model ids). */
  agentLabel?: string;
}

export interface ToolResult {
  ok: boolean;
  /** Compact human/agent-readable summary of what happened. */
  summary: string;
  /** Structured payload (already size-capped). */
  data?: unknown;
  error?: string;
}

export interface Tool {
  readonly name: string;
  readonly description: string;
  /** JSON Schema = both validation and model-facing definition. */
  readonly schema: JSONSchema;
  /** True when the tool needs an explicit workspace (almost all fs tools). */
  readonly requiresWorkspace?: boolean;
  /** Escalate the base tier from concrete arguments (e.g. overwrite). */
  escalateTier?: (input: Record<string, unknown>) => RiskTier | null;
  /** One-line plain description of the action for approval prompts. */
  describe?: (input: Record<string, unknown>) => { summary: string; targets: string[]; preview?: string };
  run(input: Record<string, unknown>, ctx: ToolContext): Promise<ToolResult>;
}
