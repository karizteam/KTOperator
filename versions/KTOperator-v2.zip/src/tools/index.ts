import { ToolRegistry } from './registry.js';
import { filesystemTools } from './filesystem.js';
import { developmentTools } from './development.js';
import { systemTools } from './system.js';
import { processTools } from './processes.js';
import type { Tool } from './types.js';

/** All model-facing tools. Privileged operations live outside this registry. */
export const ALL_TOOLS: Tool[] = [...filesystemTools, ...developmentTools, ...systemTools, ...processTools];

export function createToolRegistry(extra: Tool[] = []): ToolRegistry {
  return new ToolRegistry([...ALL_TOOLS, ...extra]);
}

export { ToolRegistry } from './registry.js';
export type { Tool, ToolContext, ToolResult } from './types.js';
