export const VERSION = '0.1.0';
export const PRODUCT_NAME = 'KarizTeam Operator';
export const PACKAGE_NAME = '@karizteam/operator';
