import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { UserCancelledError } from '../errors/errors.js';

/** Tiny ANSI styling layer with TTY / NO_COLOR awareness — zero dependencies. */
export class Ui {
  readonly colorEnabled: boolean;
  readonly jsonMode: boolean;
  readonly interactive: boolean;

  constructor(options: { json?: boolean; noColor?: boolean; forceNonInteractive?: boolean } = {}) {
    this.jsonMode = options.json ?? false;
    this.interactive = !options.forceNonInteractive && Boolean(stdin.isTTY) && !this.jsonMode;
    this.colorEnabled = !options.noColor && Boolean(stdout.isTTY) && process.env['NO_COLOR'] === undefined && !this.jsonMode;
  }

  private paint(code: string, s: string): string {
    return this.colorEnabled ? `[${code}m${s}[0m` : s;
  }
  bold(s: string): string { return this.paint('1', s); }
  dim(s: string): string { return this.paint('2', s); }
  red(s: string): string { return this.paint('31', s); }
  green(s: string): string { return this.paint('32', s); }
  yellow(s: string): string { return this.paint('33', s); }
  blue(s: string): string { return this.paint('34', s); }
  magenta(s: string): string { return this.paint('35', s); }
  cyan(s: string): string { return this.paint('36', s); }

  info(msg: string): void { if (!this.jsonMode) stdout.write(`${msg}\n`); }
  step(msg: string): void { if (!this.jsonMode) stdout.write(`${this.cyan('›')} ${msg}\n`); }
  success(msg: string): void { if (!this.jsonMode) stdout.write(`${this.green('✔')} ${msg}\n`); }
  warn(msg: string): void { if (!this.jsonMode) stdout.write(`${this.yellow('!')} ${msg}\n`); }
  error(msg: string): void { process.stderr.write(`${this.red('✖')} ${msg}\n`); }

  /** Streamed model tokens. */
  token(chunk: string): void {
    if (!this.jsonMode) stdout.write(chunk);
  }
  endStream(): void {
    if (!this.jsonMode) stdout.write('\n');
  }

  /** Emit a machine-readable result; in human mode render via `render`. */
  emit(data: unknown, render?: (data: never) => string): void {
    if (this.jsonMode) {
      stdout.write(`${JSON.stringify(data, null, 2)}\n`);
    } else if (render) {
      stdout.write(`${render(data as never)}\n`);
    }
  }

  /**
   * One shared line reader for the whole session. Creating a fresh interface
   * per question swallows input that arrives in bulk (pasted keys, piped
   * answers) because each new interface re-reads stdin from its own position.
   * The reader pauses between questions so the process can still exit
   * naturally when nothing is pending.
   */
  private rl: readline.Interface | null = null;
  /**
   * Typeahead handling with single-ownership routing: each parsed line is
   * handed to exactly one consumer — either the currently pending prompt or
   * the typeahead queue (bulk paste / piped answers). The interface pauses
   * when fully idle so the process can exit naturally.
   */
  private pendingLines: string[] = [];
  private pendingInputs: { resolve: (line: string) => void; reject: (err: Error) => void }[] = [];

  private getRl(): readline.Interface {
    if (!this.rl) {
      this.rl = readline.createInterface({ input: stdin, output: stdout, terminal: true });
      this.rl.on('line', (line) => {
        const pending = this.pendingInputs.shift();
        if (pending) pending.resolve(line);
        else this.pendingLines.push(line);
        this.maybePause();
      });
      this.rl.on('close', () => {
        this.rl = null;
        for (const pending of this.pendingInputs.splice(0)) pending.reject(new UserCancelledError());
      });
      this.rl.on('SIGINT', () => {
        const pending = this.pendingInputs.shift();
        pending?.reject(new UserCancelledError());
      });
    }
    return this.rl;
  }

  private maybePause(): void {
    if (this.rl && this.pendingInputs.length === 0 && this.pendingLines.length === 0) this.rl.pause();
  }

  /** Ask one line of input, honoring queued typeahead first. */
  private lineQuestion(promptText: string): Promise<string> {
    if (!this.interactive) return Promise.reject(new UserCancelledError('Interactive input requested in a non-interactive session.'));
    if (this.pendingLines.length > 0) {
      const line = this.pendingLines.shift()!;
      stdout.write(`${promptText}${line}\n`);
      return Promise.resolve(line);
    }
    const rl = this.getRl();
    rl.resume();
    stdout.write(promptText);
    return new Promise<string>((resolve, reject) => {
      this.pendingInputs.push({
        resolve: (line) => resolve(line),
        reject: (err) => reject(err),
      });
    });
  }

  /** Low-level single-line prompt used by the interactive console chatbox. */
  async question(prompt: string): Promise<string> {
    return this.lineQuestion(prompt);
  }

  /** Free-form input. `mask` replaces typed characters (API keys). */
  async promptInput(question: string, options: { mask?: boolean; defaultValue?: string; required?: boolean } = {}): Promise<string> {
    if (!this.interactive) throw new UserCancelledError('Interactive input requested in a non-interactive session.');
    if (!options.mask) {
      const suffix = options.defaultValue ? ` ${this.dim(`(${options.defaultValue})`)}` : '';
      const answer = await this.lineQuestion(`${question}${suffix}: `);
      const value = answer.trim() === '' && options.defaultValue !== undefined ? options.defaultValue : answer.trim();
      if (options.required && value === '') throw new UserCancelledError('A value is required.');
      return value;
    }
    // Masked secrets are captured in raw mode with no readline interface at
    // all — a readline interface in terminal mode echoes the raw characters,
    // which would print the key to the screen. The persistent reader is
    // closed first so it can neither echo nor buffer the secret.
    // A secret typed ahead (paste/pipe) was already parsed by the line reader;
    // replay it instead of waiting for bytes that will never arrive.
    if (this.pendingLines.length > 0) {
      const typed = this.pendingLines.shift()!;
      if (options.required && typed.trim() === '') throw new UserCancelledError('A value is required.');
      stdout.write(`${question}: ${'*'.repeat(typed.trim().length)}\n`);
      return typed.trim();
    }
    return new Promise<string>((resolve, reject) => {
      if (this.rl) {
        this.rl.close();
        this.rl = null;
      }
      let buf = '';
      const cleanup = () => {
        stdin.removeListener('data', onData);
        if (stdin.isTTY) stdin.setRawMode(false);
        stdin.pause();
      };
      const finish = (err?: Error) => {
        cleanup();
        stdout.write('\n');
        if (err !== undefined) reject(err);
        else if (options.required && buf.trim() === '') reject(new UserCancelledError('A value is required.'));
        else resolve(buf.trim());
      };
      const onData = (chunk: Buffer) => {
        for (const ch of chunk.toString('utf8')) {
          if (ch === '\u0003') { finish(new UserCancelledError()); return; }
          if (ch === '\r' || ch === '\n') { finish(); return; }
          if (ch === '\u007f' || ch === '\b') {
            buf = buf.slice(0, -1);
            stdout.write('\b \b');
          } else {
            buf += ch;
            stdout.write('*');
          }
        }
      };
      if (stdin.isTTY) stdin.setRawMode(true);
      stdin.resume();
      stdout.write(`${question}: `);
      stdin.on('data', onData);
    });
  }

  /** Single-key choice, e.g. approval prompts. Returns the chosen key. */
  async promptChoice(question: string, choices: readonly { key: string; label: string }[]): Promise<string> {
    if (!this.interactive) throw new UserCancelledError('Approval requested in a non-interactive session.');
    const rendered = choices.map((c) => `[${this.bold(c.key)}] ${c.label}`).join('   ');
    const valid = new Set(choices.map((c) => c.key.toLowerCase()));
    for (;;) {
      const answer = (await this.lineQuestion(`${question}\n${rendered}: `)).trim().toLowerCase();
      if (valid.has(answer)) return answer;
      stdout.write(`Please answer one of: ${choices.map((c) => c.key).join(', ')}\n`);
    }
  }

  async confirm(question: string, defaultNo = true): Promise<boolean> {
    const answer = await this.promptChoice(question, [
      { key: 'y', label: 'yes' },
      { key: 'n', label: defaultNo ? 'no (default)' : 'no' },
    ]);
    return answer === 'y';
  }

  /** Vertical list picker for setup wizards; returns the selected index. */
  async promptSelect(question: string, options: readonly string[]): Promise<number> {
    if (!this.interactive) throw new UserCancelledError('Interactive selection requested in a non-interactive session.');
    stdout.write(`${question}\n`);
    options.forEach((opt, i) => stdout.write(`  ${this.cyan(String(i + 1))}) ${opt}\n`));
    for (;;) {
      const answer = (await this.lineQuestion(`Choose 1-${options.length}: `)).trim();
      const n = Number.parseInt(answer, 10);
      if (Number.isInteger(n) && n >= 1 && n <= options.length) return n - 1;
      stdout.write('Invalid selection.\n');
    }
  }

  /** Render a titled detail box used by approval prompts. */
  box(title: string, lines: readonly string[]): void {
    if (this.jsonMode) return;
    const width = Math.min(Math.max(...lines.map((l) => l.length), title.length) + 4, 100);
    const top = `┌─ ${title} ${'─'.repeat(Math.max(0, width - title.length - 4))}┐`;
    stdout.write(`${this.yellow(top)}\n`);
    for (const line of lines) {
      const clipped = line.length > width - 4 ? `${line.slice(0, width - 7)}...` : line;
      stdout.write(`${this.yellow('│')} ${clipped}${' '.repeat(Math.max(0, width - clipped.length - 3))}${this.yellow('│')}\n`);
    }
    stdout.write(`${this.yellow(`└${'─'.repeat(width)}┘`)}\n`);
  }
}
