import { spawn, type ChildProcess } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { SandboxError } from '../../errors/errors.js';
import { isWindows } from '../../platform/paths.js';

/**
 * Managed process execution: structured argv (no shell by default), minimal
 * environment, timeout, bounded output capture, and guaranteed process-tree
 * cleanup on cancellation. This is the last stop before the OS — sandbox
 * backends build on top of it.
 */

export interface ManagedExecSpec {
  argv: string[];
  cwd: string;
  env: Record<string, string>;
  timeoutMs: number;
  maxOutputBytes: number;
  signal?: AbortSignal;
  /** Drop to this uid/gid (POSIX, only when we are allowed to). */
  uid?: number;
  gid?: number;
  /** Prefix wrapper already resolved to argv (e.g. prlimit / docker run). */
  label?: string;
}

export interface ManagedProcessResult {
  id: string;
  argv: string[];
  exitCode: number | null;
  signal: string | null;
  timedOut: boolean;
  aborted: boolean;
  outputTruncated: boolean;
  stdout: string;
  stderr: string;
  durationMs: number;
}

export interface ManagedProcessInfo {
  id: string;
  argv: string[];
  startedAt: string;
  running: boolean;
  label?: string;
}

const SHELL_NAMES = new Set([
  'sh', 'bash', 'zsh', 'dash', 'fish', 'ksh', 'csh', 'tcsh',
  'cmd', 'cmd.exe', 'powershell', 'powershell.exe', 'pwsh', 'pwsh.exe',
  'command.com', 'wsl', 'wsl.exe',
]);

export function isShellExecutable(name: string): boolean {
  // Sneak attempt like "/bin/sh -c 'id'" as a single argv token: check the first word's basename.
  const firstToken = name.trim().split(/\s+/)[0] ?? name;
  return SHELL_NAMES.has(path.basename(firstToken).toLowerCase());
}

/** Resolve an executable name against a PATH-like string; no shell involved. */
export async function resolveExecutable(name: string, envPath: string): Promise<string> {
  if (name.includes('/') || name.includes('\\')) {
    await assertExecutable(name);
    return name;
  }
  const exts = isWindows ? (process.env['PATHEXT'] ?? '.EXE;.CMD;.BAT;.COM').split(';') : [''];
  for (const dir of envPath.split(path.delimiter)) {
    if (!dir) continue;
    for (const ext of exts) {
      const candidate = path.join(dir, name + ext);
      try {
        await assertExecutable(candidate);
        return candidate;
      } catch {
        /* keep looking */
      }
    }
  }
  throw new SandboxError('execution', `Executable not found on the allowed PATH: ${name}`, {
    hint: 'Use an absolute path or check the command name.',
  });
}

async function assertExecutable(p: string): Promise<void> {
  const stat = await fs.stat(p);
  if (!stat.isFile()) throw new SandboxError('execution', `Not a file: ${p}`);
  if (!isWindows && (stat.mode & 0o111) === 0) {
    throw new SandboxError('execution', `File is not executable: ${p}`);
  }
}

class BoundedBuffer {
  private chunks: Buffer[] = [];
  private size = 0;
  truncated = false;

  constructor(private readonly max: number) {}

  push(chunk: Buffer): void {
    if (this.size >= this.max) {
      this.truncated = true;
      return;
    }
    const remaining = this.max - this.size;
    if (chunk.length > remaining) {
      this.chunks.push(chunk.subarray(0, remaining));
      this.size += remaining;
      this.truncated = true;
    } else {
      this.chunks.push(chunk);
      this.size += chunk.length;
    }
  }

  text(): string {
    return Buffer.concat(this.chunks).toString('utf8');
  }
}

interface ActiveHandle {
  info: ManagedProcessInfo;
  child: ChildProcess;
  kill: (reason: string) => void;
}

const HISTORY_LIMIT = 50;

export class ManagedProcessRunner {
  private readonly active = new Map<string, ActiveHandle>();
  private readonly history: ManagedProcessResult[] = [];

  list(): ManagedProcessInfo[] {
    return [...this.active.values()].map((h) => h.info);
  }

  inspect(id: string): ManagedProcessInfo | ManagedProcessResult | undefined {
    const live = this.active.get(id);
    if (live) return live.info;
    return this.history.find((r) => r.id === id);
  }

  async terminate(id: string, reason = 'terminated by user'): Promise<boolean> {
    const handle = this.active.get(id);
    if (!handle) return false;
    handle.kill(reason);
    return true;
  }

  async run(spec: ManagedExecSpec): Promise<ManagedProcessResult> {
    if (spec.argv.length === 0) throw new SandboxError('execution', 'Empty command argv.');
    const id = randomUUID();
    const startedAt = new Date();
    const stdout = new BoundedBuffer(spec.maxOutputBytes);
    const stderr = new BoundedBuffer(spec.maxOutputBytes);

    const child = spawn(spec.argv[0]!, spec.argv.slice(1), {
      cwd: spec.cwd,
      env: spec.env,
      shell: false,
      windowsHide: true,
      detached: !isWindows, // own process group so we can kill the tree
      stdio: ['ignore', 'pipe', 'pipe'],
      ...(spec.uid !== undefined ? { uid: spec.uid } : {}),
      ...(spec.gid !== undefined ? { gid: spec.gid } : {}),
    });
    child.stdout?.on('data', (c: Buffer) => stdout.push(c));
    child.stderr?.on('data', (c: Buffer) => stderr.push(c));

    const info: ManagedProcessInfo = { id, argv: spec.argv, startedAt: startedAt.toISOString(), running: true, ...(spec.label ? { label: spec.label } : {}) };

    return new Promise<ManagedProcessResult>((resolve) => {
      let timedOut = false;
      let aborted = false;
      let settled = false;

      const finish = (exitCode: number | null, signal: string | null) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        spec.signal?.removeEventListener('abort', onAbort);
        this.active.delete(id);
        const result: ManagedProcessResult = {
          id,
          argv: spec.argv,
          exitCode,
          signal,
          timedOut,
          aborted,
          outputTruncated: stdout.truncated || stderr.truncated,
          stdout: stdout.text(),
          stderr: stderr.text(),
          durationMs: Date.now() - startedAt.getTime(),
        };
        this.history.push(result);
        if (this.history.length > HISTORY_LIMIT) this.history.shift();
        resolve(result);
      };

      let killTimer: NodeJS.Timeout | null = null;
      const killTree = (_reason: string) => {
        if (!child.pid) return;
        try {
          if (isWindows) {
            // /T kills the process tree.
            spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { shell: false, windowsHide: true });
          } else {
            process.kill(-child.pid, 'SIGTERM'); // the whole group
            killTimer = setTimeout(() => {
              try {
                if (child.pid) process.kill(-child.pid, 'SIGKILL');
              } catch {
                /* already gone */
              }
            }, 5000);
          }
        } catch {
          try {
            child.kill('SIGKILL');
          } catch {
            /* gone */
          }
        }
      };

      const timer = setTimeout(() => {
        timedOut = true;
        killTree('timeout');
      }, spec.timeoutMs);

      const onAbort = () => {
        aborted = true;
        killTree('cancelled');
      };
      if (spec.signal) {
        if (spec.signal.aborted) onAbort();
        else spec.signal.addEventListener('abort', onAbort, { once: true });
      }

      this.active.set(id, { info, child, kill: killTree });

      child.on('error', (err) => {
        stderr.push(Buffer.from(`spawn error: ${err.message}`));
        finish(null, null);
      });
      child.on('close', (code, sig) => {
        if (killTimer) clearTimeout(killTimer);
        finish(code, sig);
      });
    });
  }
}
