# Permission & Approval Matrix

Four risk tiers; the policy engine decides from the tier plus hard rules.
Approvals can come only from the interactive user prompt or an explicit
`--yes read|write|all` grant (bounded by `security.maxAutoApproveTier`).

| Tier | Meaning | Default |
|---|---|---|
| 0 — read-only | Inspection within the workspace | Allowed by policy |
| 1 — reversible modification | Creates/edits (snapshotted) | Approval required |
| 2 — destructive/high-impact | Deletes, overwrites, managed-process kill | Per-operation approval; no session "always" grants |
| 3 — privileged/external | Command execution, builds, installs | Per-operation approval in a terminal; `--yes all` required otherwise; audited loudly |

Hard denials (no approval can override): anything outside the workspace,
shell interpreters as executables, admin/root execution, exposing the
container-runtime socket to the sandbox.

## Tool classification

| Tool | Tier | Notes |
|---|---|---|
| list_directory, read_file, search_files, search_text, inspect_file_metadata, generate_diff | 0 | Output-capped, redaction applied |
| inspect_project, detect_project_type, inspect_package_json, inspect_git_status | 0 | git runs sandboxed, read-only |
| get_operating_system, get_runtime_versions, get_cpu_summary, get_memory_summary, get_disk_usage, get_process_summary | 0 | Read-only system views; process LIST only |
| inspect_command_result | 0 | Operator-managed processes only |
| create_file | 1 → 2 | Escalates to 2 when overwriting an existing file |
| edit_file | 1 | Exact-match edits; atomic; diff returned |
| move_file | 1 → 2 | Escalates when overwriting destination; both ends must be in-workspace |
| delete_file | 2 | Single files only; snapshot first; no recursive deletion by design |
| terminate_managed_process | 2 | Only Operator-managed ids |
| run_tests, run_typecheck, run_linter, run_build | 3 | Existing npm scripts only; sandboxed; network per config |
| execute_approved_command | 3 | argv-only; no shells; sandboxed |

## Approval prompt contents

Every interactive request displays: the exact operation, the tool, the risk
tier with its label, precise target paths (up to 5, then a count), the
requesting provider/model, and a content preview (diff for edits, first
lines for creates, the argv for commands). Choices:

- tier ≤ 1: `y` once / `a` always-this-session (this tool + these targets) / `n`
- tier ≥ 2: `y` once / `n` — always grants do not exist.

Denials are returned to the model as structured tool errors ("do not retry
the same action") and three denials stop the session — by design, Operator
does not push against the security policy.

## Non-interactive operation

- `--json` forces non-interactive: approvals then come only from `--yes`.
- No `--yes` → tier ≥ 1 actions are denied with a clear explanation.
- `--yes read` → tier 0 only. `--yes write` → tiers 0–1. `--yes all` → all
  tiers (use deliberately; everything is audited).
- `security.maxAutoApproveTier` (default 1) caps unattended operation.

## Network policy

- Sandbox network: OFF by default (`sandbox.network`).
- Workspace content reaches a provider only through the configured profile's
  endpoint — there are no other egress paths, no telemetry, and no silent
  provider switching.
- Custom endpoints: HTTPS-only, no URL credentials, no redirects; private
  targets require `trustedLocal: true` on the profile (or
  `network.allowPrivateProviderEndpoints` for advanced cases).
