import readline from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { UserCancelledError } from '../errors/errors.js';

/** Primary brand hex color: #8B9A6E (RGB: 139, 154, 110) */
export const BRAND_HEX = '#8B9A6E';
export const BRAND_RGB: readonly [number, number, number] = [139, 154, 110];
export const BRAND_LIGHT_RGB: readonly [number, number, number] = [178, 194, 148];
export const BRAND_DARK_RGB: readonly [number, number, number] = [98, 112, 74];

const ANSI_STRIP_RE = /\x1b\[[0-9;]*m/g;
constRTL_CHAR_RE = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;

/** Tiny ANSI styling layer with TrueColor (#8B9A6E), RTL/Persian text shaping, and interactive animations. */
export class Ui {
  readonly colorEnabled: boolean;
  readonly jsonMode: boolean;
  readonly interactive: boolean;

  constructor(options: { json?: boolean; noColor?: boolean; forceNonInteractive?: boolean } = {}) {
    this.jsonMode = options.json ?? false;
    this.interactive = !options.forceNonInteractive && Boolean(stdin.isTTY) && !this.jsonMode;
    this.colorEnabled = !options.noColor && Boolean(stdout.isTTY) && process.env['NO_COLOR'] === undefined && !this.jsonMode;

    // Ensure UTF-8 encoding on stdio so Persian/RTL characters never break or garble.
    try {
      if (typeof stdin.setEncoding === 'function') stdin.setEncoding('utf8');
      if (typeof stdout.setDefaultEncoding === 'function') stdout.setDefaultEncoding('utf8');
    } catch {
      /* ignore if stream does not allow encoding changes */
    }
  }

  private paint(code: string, s: string): string {
    return this.colorEnabled ? `\x1b[${code}m${s}\x1b[0m` : s;
  }

  /** Paint with 24-bit TrueColor RGB. */
  rgb(r: number, g: number, b: number, s: string): string {
    return this.paint(`38;2;${r};${g};${b}`, s);
  }

  /** Paint background with 24-bit TrueColor RGB. */
  bgRgb(r: number, g: number, b: number, s: string): string {
    return this.paint(`48;2;${r};${g};${b}`, s);
  }

  /** Brand primary color #8B9A6E (139, 154, 110). */
  brand(s: string): string {
    return this.rgb(BRAND_RGB[0], BRAND_RGB[1], BRAND_RGB[2], s);
  }

  /** Brand bold #8B9A6E. */
  brandBold(s: string): string {
    return this.colorEnabled ? `\x1b[1;38;2;${BRAND_RGB[0]};${BRAND_RGB[1]};${BRAND_RGB[2]}m${s}\x1b[0m` : s;
  }

  /** Lighter accent of #8B9A6E for highlights. */
  brandLight(s: string): string {
    return this.rgb(BRAND_LIGHT_RGB[0], BRAND_LIGHT_RGB[1], BRAND_LIGHT_RGB[2], s);
  }

  /** Darker shade of #8B9A6E for borders and subtle chrome. */
  brandDark(s: string): string {
    return this.rgb(BRAND_DARK_RGB[0], BRAND_DARK_RGB[1], BRAND_DARK_RGB[2], s);
  }

  /** High-contrast badge with #8B9A6E background. */
  brandBadge(s: string): string {
    return this.colorEnabled ? `\x1b[1;38;2;15;18;12;48;2;${BRAND_RGB[0]};${BRAND_RGB[1]};${BRAND_RGB[2]}m ${s} \x1b[0m` : `[${s}]`;
  }

  bold(s: string): string { return this.paint('1', s); }
  dim(s: string): string { return this.paint('2', s); }
  red(s: string): string { return this.paint('31', s); }
  green(s: string): string { return this.brandLight(s); }
  yellow(s: string): string { return this.paint('33', s); }
  blue(s: string): string { return this.brand(s); }
  magenta(s: string): string { return this.brandBold(s); }
  cyan(s: string): string { return this.brand(s); }

  /**
   * Normalize Persian/Arabic text for clean terminal rendering:
   * - Applies NFC composition so detached hamza/yeh/kaf combine cleanly
   * - Preserves Zero-Width Non-Joiner (ZWNJ) for proper Persian word joining
   * - Isolates directional runs per line when mixed with LTR code/paths so borders never break.
   */
  formatPersianText(text: string): string {
    const normalized = text.normalize('NFC');
    if (!constRTL_CHAR_RE.test(normalized)) return normalized;
    return normalized
      .split('\n')
      .map((line) => {
        if (!constRTL_CHAR_RE.test(line)) return line;
        // Wrap lines starting with Persian characters in Unicode FSI...PDI (U+2068 ... U+2069)
        // so BiDi-aware terminals keep connected letter shaping and proper alignment.
        return `\u2068${line}\u2069`;
      })
      .join('\n');
  }

  /** Visible character width ignoring ANSI codes and zero-width BiDi marks. */
  visibleLength(s: string): number {
    const clean = s
      .replace(ANSI_STRIP_RE, '')
      .replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
      .normalize('NFC');
    return [...clean].length;
  }

  info(msg: string): void { if (!this.jsonMode) stdout.write(`${this.formatPersianText(msg)}\n`); }
  step(msg: string): void { if (!this.jsonMode) stdout.write(`${this.brandBold('◈')} ${this.formatPersianText(msg)}\n`); }
  success(msg: string): void { if (!this.jsonMode) stdout.write(`${this.brandLight('✔')} ${this.formatPersianText(msg)}\n`); }
  warn(msg: string): void { if (!this.jsonMode) stdout.write(`${this.yellow('⚠')} ${this.formatPersianText(msg)}\n`); }
  error(msg: string): void { process.stderr.write(`${this.red('✖')} ${this.formatPersianText(msg)}\n`); }

  /** Streamed model tokens with NFC normalization for clean multi-byte Persian streaming. */
  token(chunk: string): void {
    if (!this.jsonMode) stdout.write(chunk.normalize('NFC'));
  }
  endStream(): void {
    if (!this.jsonMode) stdout.write('\n');
  }

  /**
   * Animated console splash screen with #8B9A6E theme, KT Operator banner,
   * "MadeByKariz" slogan, and smooth loading bar.
   */
  async splashScreen(version: string): Promise<void> {
    if (this.jsonMode) return;

    const logoLines = [
      '  ██╗  ██╗████████╗     ██████╗ ██████╗ ███████╗██████╗  █████╗ ████████╗ ██████╗ ██████╗ ',
      '  ██║ ██╔╝╚══██╔══╝    ██╔═══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔═══██╗██╔══██╗',
      '  █████╔╝    ██║       ██║   ██║██████╔╝█████╗  ██████╔╝███████║   ██║   ██║   ██║██████╔╝',
      '  ██╔═██╗    ██║       ██║   ██║██╔═══╝ ██╔══╝  ██╔══██╗██╔══██║   ██║   ██║   ██║██╔══██╗',
      '  ██║  ██╗   ██║       ╚██████╔╝██║     ███████╗██║  ██║██║  ██║   ██║   ╚██████╔╝██║  ██║',
      '  ╚═╝  ╚═╝   ╚═╝        ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝',
    ];

    const divider = this.brandDark('  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    stdout.write('\n');
    for (let i = 0; i < logoLines.length; i++) {
      const shade = i < 2 ? this.brandLight(logoLines[i]!) : i < 4 ? this.brandBold(logoLines[i]!) : this.brand(logoLines[i]!);
      stdout.write(`${shade}\n`);
    }
    stdout.write(`${divider}\n`);
    stdout.write(
      `  ${this.brandBadge('KT Operator')} ${this.brandLight(`v${version}`)}  ${this.brandDark('│')}  ${this.brandBold('✦ MadeByKariz ✦')}  ${this.brandDark('│')}  ${this.dim('Theme #8B9A6E · Persian/RTL Ready')}\n`,
    );
    stdout.write(`${divider}\n`);

    if (!this.interactive) {
      stdout.write('\n');
      return;
    }

    // Smooth console loading animation in #8B9A6E theme
    const stages = [
      'Initializing security engine...',
      'Loading multi-provider adapters...',
      'Configuring UTF-8 / Persian RTL terminal...',
      'KT Operator Ready!',
    ];
    const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    const totalTicks = 16;
    const barWidth = 28;

    for (let tick = 0; tick <= totalTicks; tick++) {
      const ratio = tick / totalTicks;
      const filled = Math.round(ratio * barWidth);
      const empty = barWidth - filled;
      const bar = `${this.brandBold('█'.repeat(filled))}${this.brandDark('░'.repeat(empty))}`;
      const pct = String(Math.round(ratio * 100)).padStart(3, ' ');
      const frame = this.brandLight(frames[tick % frames.length]!);
      const stageIdx = Math.min(stages.length - 1, Math.floor(ratio * stages.length));
      const stageText = this.brand(stages[stageIdx]!);
      stdout.write(`\r  ${frame} [${bar}] ${this.brandBold(`${pct}%`)} ${stageText}          `);
      await new Promise((r) => setTimeout(r, 35));
    }
    stdout.write(`\r  ${this.brandLight('✔')} [${this.brandBold('█'.repeat(barWidth))}] ${this.brandBold('100%')} ${this.brandLight('KT Operator Ready · MadeByKariz')}            \n\n`);
  }

  /** Run an async task with an inline #8B9A6E spinner in interactive mode. */
  async withSpinner<T>(label: string, fn: () => Promise<T>): Promise<T> {
    if (!this.interactive || this.jsonMode) {
      this.step(label);
      return fn();
    }
    const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    let idx = 0;
    const formatted = this.formatPersianText(label);
    const timer = setInterval(() => {
      const f = this.brandLight(frames[idx++ % frames.length]!);
      stdout.write(`\r${f} ${this.brand(formatted)}   `);
    }, 70);
    try {
      const result = await fn();
      clearInterval(timer);
      stdout.write(`\r${this.brandLight('✔')} ${this.brand(formatted)}   \n`);
      return result;
    } catch (err) {
      clearInterval(timer);
      stdout.write(`\r${this.red('✖')} ${formatted}   \n`);
      throw err;
    }
  }

  /** Emit a machine-readable result; in human mode render via `render`. */
  emit(data: unknown, render?: (data: never) => string): void {
    if (this.jsonMode) {
      stdout.write(`${JSON.stringify(data, null, 2)}\n`);
    } else if (render) {
      const out = render(data as never);
      if (out !== '') stdout.write(`${this.formatPersianText(out)}\n`);
    }
  }

  private rl: readline.Interface | null = null;
  private pendingLines: string[] = [];
  private pendingInputs: { resolve: (line: string) => void; reject: (err: Error) => void }[] = [];

  private getRl(): readline.Interface {
    if (!this.rl) {
      this.rl = readline.createInterface({ input: stdin, output: stdout, terminal: true });
      this.rl.on('line', (line) => {
        const normalized = line.normalize('NFC');
        const pending = this.pendingInputs.shift();
        if (pending) pending.resolve(normalized);
        else this.pendingLines.push(normalized);
        this.maybePause();
      });
      this.rl.on('close', () => {
        this.rl = null;
        for (const pending of this.pendingInputs.splice(0)) pending.reject(new UserCancelledError());
      });
      this.rl.on('SIGINT', () => {
        const pending = this.pendingInputs.shift();
        pending?.reject(new UserCancelledError());
      });
    }
    return this.rl;
  }

  private maybePause(): void {
    if (this.rl && this.pendingInputs.length === 0 && this.pendingLines.length === 0) this.rl.pause();
  }

  /** Ask one line of input, honoring queued typeahead first. */
  private lineQuestion(promptText: string): Promise<string> {
    if (!this.interactive) return Promise.reject(new UserCancelledError('Interactive input requested in a non-interactive session.'));
    if (this.pendingLines.length > 0) {
      const line = this.pendingLines.shift()!;
      stdout.write(`${promptText}${line}\n`);
      return Promise.resolve(line);
    }
    const rl = this.getRl();
    rl.resume();
    stdout.write(promptText);
    return new Promise<string>((resolve, reject) => {
      this.pendingInputs.push({
        resolve: (line) => resolve(line),
        reject: (err) => reject(err),
      });
    });
  }

  /** Low-level single-line prompt used by the interactive console chatbox. */
  async question(prompt: string): Promise<string> {
    return this.lineQuestion(prompt);
  }

  /** Free-form input. `mask` replaces typed characters (API keys). */
  async promptInput(question: string, options: { mask?: boolean; defaultValue?: string; required?: boolean } = {}): Promise<string> {
    if (!this.interactive) throw new UserCancelledError('Interactive input requested in a non-interactive session.');
    const styledQ = this.brandBold(`◈ ${this.formatPersianText(question)}`);
    if (!options.mask) {
      const suffix = options.defaultValue ? ` ${this.dim(`(${options.defaultValue})`)}` : '';
      const answer = await this.lineQuestion(`${styledQ}${suffix}: `);
      const value = answer.trim() === '' && options.defaultValue !== undefined ? options.defaultValue : answer.trim();
      if (options.required && value === '') throw new UserCancelledError('A value is required.');
      return value.normalize('NFC');
    }
    if (this.pendingLines.length > 0) {
      const typed = this.pendingLines.shift()!;
      if (options.required && typed.trim() === '') throw new UserCancelledError('A value is required.');
      stdout.write(`${styledQ}: ${this.brandLight('*'.repeat(typed.trim().length))}\n`);
      return typed.trim();
    }
    return new Promise<string>((resolve, reject) => {
      if (this.rl) {
        this.rl.close();
        this.rl = null;
      }
      let buf = '';
      const cleanup = () => {
        stdin.removeListener('data', onData);
        if (stdin.isTTY) stdin.setRawMode(false);
        stdin.pause();
      };
      const finish = (err?: Error) => {
        cleanup();
        stdout.write('\n');
        if (err !== undefined) reject(err);
        else if (options.required && buf.trim() === '') reject(new UserCancelledError('A value is required.'));
        else resolve(buf.trim().normalize('NFC'));
      };
      const onData = (chunk: Buffer | string) => {
        const str = typeof chunk === 'string' ? chunk : chunk.toString('utf8');
        for (const ch of str) {
          if (ch === '\u0003') { finish(new UserCancelledError()); return; }
          if (ch === '\r' || ch === '\n') { finish(); return; }
          if (ch === '\u007f' || ch === '\b') {
            if (buf.length > 0) {
              buf = [...buf].slice(0, -1).join('');
              stdout.write('\b \b');
            }
          } else {
            buf += ch;
            stdout.write(this.brandLight('*'));
          }
        }
      };
      if (stdin.isTTY) stdin.setRawMode(true);
      stdin.resume();
      stdout.write(`${styledQ}: `);
      stdin.on('data', onData);
    });
  }

  /** Single-key choice, e.g. approval prompts. Returns the chosen key. */
  async promptChoice(question: string, choices: readonly { key: string; label: string }[]): Promise<string> {
    if (!this.interactive) throw new UserCancelledError('Approval requested in a non-interactive session.');
    const rendered = choices.map((c) => `${this.brandDark('[')}${this.brandBold(c.key)}${this.brandDark(']')} ${c.label}`).join('   ');
    const valid = new Set(choices.map((c) => c.key.toLowerCase()));
    for (;;) {
      const answer = (await this.lineQuestion(`${this.brandBold('◈')} ${this.formatPersianText(question)}\n  ${rendered}: `)).trim().toLowerCase();
      if (valid.has(answer)) return answer;
      stdout.write(`Please answer one of: ${choices.map((c) => c.key).join(', ')}\n`);
    }
  }

  async confirm(question: string, defaultNo = true): Promise<boolean> {
    const answer = await this.promptChoice(question, [
      { key: 'y', label: 'yes / بله' },
      { key: 'n', label: defaultNo ? 'no (default) / خیر' : 'no / خیر' },
    ]);
    return answer === 'y';
  }

  /** Vertical list picker for setup wizards; returns the selected index. */
  async promptSelect(question: string, options: readonly string[]): Promise<number> {
    if (!this.interactive) throw new UserCancelledError('Interactive selection requested in a non-interactive session.');
    stdout.write(`\n${this.brandBold('╭─')} ${this.bold(this.formatPersianText(question))}\n`);
    options.forEach((opt, i) => {
      const num = String(i + 1).padStart(2, ' ');
      stdout.write(`${this.brandBold('│')}  ${this.brandLight(`${num})`)} ${this.formatPersianText(opt)}\n`);
    });
    for (;;) {
      const answer = (await this.lineQuestion(`${this.brandBold('╰─›')} ${this.brand(`Choose 1-${options.length}`)}: `)).trim();
      const n = Number.parseInt(answer, 10);
      if (Number.isInteger(n) && n >= 1 && n <= options.length) return n - 1;
      stdout.write(`${this.yellow('⚠')} Invalid selection. Please enter a number between 1 and ${options.length}.\n`);
    }
  }

  /** Render a titled detail box themed in #8B9A6E with accurate visible width for Persian/UTF-8 text. */
  box(title: string, lines: readonly string[]): void {
    if (this.jsonMode) return;
    const formattedTitle = this.formatPersianText(title);
    const titleLen = this.visibleLength(formattedTitle);
    const maxLineLen = lines.reduce((m, l) => Math.max(m, this.visibleLength(l)), 0);
    const width = Math.min(Math.max(maxLineLen, titleLen) + 6, 100);
    const topDash = '─'.repeat(Math.max(0, width - titleLen - 5));
    const top = `╭─ ${this.brandBold(formattedTitle)} ${this.brandDark(topDash)}╮`;
    stdout.write(`${this.brandDark('╭')}${top.slice(1)}\n`);
    for (const rawLine of lines) {
      const line = this.formatPersianText(rawLine);
      const vLen = this.visibleLength(line);
      const clipped = vLen > width - 4 ? `${line.slice(0, width - 7)}...` : line;
      const pad = ' '.repeat(Math.max(0, width - Math.min(vLen, width - 4) - 3));
      stdout.write(`${this.brandDark('│')} ${clipped}${pad}${this.brandDark('│')}\n`);
    }
    stdout.write(`${this.brandDark(`╰${'─'.repeat(width - 1)}╯`)}\n`);
  }
}
