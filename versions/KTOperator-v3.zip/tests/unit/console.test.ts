import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { parseSlashCommand } from '../../src/commands/console.js';
import { Ui, BRAND_HEX, BRAND_RGB } from '../../src/cli/ui.js';

describe('parseSlashCommand', () => {
  it('returns null for regular messages', () => {
    assert.equal(parseSlashCommand('run the tests'), null);
    assert.equal(parseSlashCommand(''), null);
    assert.equal(parseSlashCommand('explain /etc/hosts'), null);
  });

  it('parses a bare command', () => {
    assert.deepEqual(parseSlashCommand('/exit'), { name: 'exit', args: '' });
    assert.deepEqual(parseSlashCommand('/sandbox'), { name: 'sandbox', args: '' });
    assert.deepEqual(parseSlashCommand('/status'), { name: 'status', args: '' });
    assert.deepEqual(parseSlashCommand('/doctor'), { name: 'doctor', args: '' });
  });

  it('parses command plus arguments', () => {
    assert.deepEqual(parseSlashCommand('/provider use or'), { name: 'provider', args: 'use or' });
    assert.deepEqual(parseSlashCommand('/model reload'), { name: 'model', args: 'reload' });
    assert.deepEqual(parseSlashCommand('/workspace /tmp/foo bar'), { name: 'workspace', args: '/tmp/foo bar' });
  });

  it('normalizes case and surrounding whitespace', () => {
    assert.deepEqual(parseSlashCommand('  /EXIT  '), { name: 'exit', args: '' });
    assert.deepEqual(parseSlashCommand('/Model Use GPT'), { name: 'model', args: 'Use GPT' });
  });

  it('does not treat a lone slash as a command', () => {
    assert.equal(parseSlashCommand('/'), null);
    assert.equal(parseSlashCommand('/ '), null);
  });
});

describe('UI Theme (#8B9A6E) & Persian/RTL Text Support', () => {
  it('exports the #8B9A6E brand color constants', () => {
    assert.equal(BRAND_HEX, '#8B9A6E');
    assert.deepEqual(BRAND_RGB, [139, 154, 110]);
  });

  it('normalizes and wraps Persian text with BiDi isolate marks without breaking ZWNJ', () => {
    const ui = new Ui({ noColor: true, forceNonInteractive: true });
    const persian = 'سلام دنیا! این یک متن فارسی‌تست است.';
    const formatted = ui.formatPersianText(persian);
    assert.ok(formatted.includes('⁨'));
    assert.ok(formatted.includes('⁩'));
    assert.ok(formatted.includes('‌'), 'must preserve ZWNJ (نیم‌فاصله)');
    assert.equal(ui.visibleLength(formatted), [...persian].length);
  });

  it('leaves pure English text untouched', () => {
    const ui = new Ui({ noColor: true, forceNonInteractive: true });
    assert.equal(ui.formatPersianText('Hello KT Operator'), 'Hello KT Operator');
  });
});
